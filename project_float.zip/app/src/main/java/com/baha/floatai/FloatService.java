package com.baha.floatai;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class FloatService extends Service {
    WindowManager wm;
    float dp;
    int sw, sh;
    Context themed;
    final Handler ui = new Handler(Looper.getMainLooper());

    View bubble;
    WindowManager.LayoutParams blp;
    boolean bubbleOn = false;

    LinearLayout panel;
    WindowManager.LayoutParams plp;
    boolean panelOn = false;
    LinearLayout msgs;
    ScrollView sv;
    EditText input;

    JSONArray history = new JSONArray();
    boolean busy = false;

    int dpi(int v) {
        return Math.round(v * dp);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("f", "Floating AI", NotificationManager.IMPORTANCE_LOW));
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Intent stopI = new Intent(this, FloatService.class).setAction("STOP");
        PendingIntent stop = PendingIntent.getService(this, 1, stopI, PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "f")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("الذكاء العائم يعمل")
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(
                        android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                        "إيقاف", stop).build())
                .build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);

        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        dp = getResources().getDisplayMetrics().density;
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        sw = dm.widthPixels;
        sh = dm.heightPixels;
        themed = new ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault);
        buildBubble();
        buildPanel();
        showBubble();
    }

    @Override
    public int onStartCommand(Intent i, int f, int id) {
        if (i != null && "STOP".equals(i.getAction())) stopSelf();
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public void onDestroy() {
        try { if (bubbleOn) wm.removeView(bubble); } catch (Exception e) { }
        try { if (panelOn) wm.removeView(panel); } catch (Exception e) { }
        super.onDestroy();
    }

    // ---------- bubble ----------
    class Bubble extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float dx, dy;
        int sx, sy;
        boolean moved;

        Bubble(Context c) {
            super(c);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        }

        @Override
        protected void onDraw(Canvas c) {
            float m = getWidth() / 2f;
            p.setColor(0xFF2563EB);
            c.drawCircle(m, m, m - 2 * dp, p);
            p.setColor(Color.WHITE);
            p.setTextSize(getWidth() * 0.36f);
            c.drawText("AI", m, m + getWidth() * 0.13f, p);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dx = e.getRawX(); dy = e.getRawY();
                    sx = blp.x; sy = blp.y; moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float mx = e.getRawX() - dx, my = e.getRawY() - dy;
                    if (!moved && Math.hypot(mx, my) > 10 * dp) moved = true;
                    if (moved) {
                        blp.x = sx + Math.round(mx);
                        blp.y = sy + Math.round(my);
                        try { wm.updateViewLayout(this, blp); } catch (Exception ex) { }
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved) showPanel();
                    return true;
            }
            return true;
        }
    }

    void buildBubble() {
        bubble = new Bubble(this);
        int s = dpi(56);
        blp = new WindowManager.LayoutParams(s, s, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        blp.gravity = Gravity.TOP | Gravity.START;
        blp.x = sw - s - dpi(8);
        blp.y = sh / 3;
    }

    void showBubble() {
        if (!bubbleOn) {
            try { wm.addView(bubble, blp); bubbleOn = true; } catch (Exception e) { }
        }
    }

    void hideBubble() {
        if (bubbleOn) {
            try { wm.removeView(bubble); } catch (Exception e) { }
            bubbleOn = false;
        }
    }

    // ---------- panel ----------
    TextView icon(String t, View.OnClickListener l) {
        TextView x = new TextView(themed);
        x.setText(t);
        x.setTextSize(18);
        x.setTextColor(Color.WHITE);
        x.setPadding(dpi(12), dpi(6), dpi(12), dpi(6));
        x.setOnClickListener(l);
        return x;
    }

    GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusDp * dp);
        return g;
    }

    void buildPanel() {
        panel = new LinearLayout(themed);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(rounded(0xF2111827, 18));

        LinearLayout header = new LinearLayout(themed);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dpi(12), dpi(4), dpi(4), dpi(4));
        header.setBackground(rounded(0xFF1F2937, 18));
        TextView title = new TextView(themed);
        title.setText("مساعد الذكاء الاصطناعي");
        title.setTextColor(Color.WHITE);
        title.setTextSize(14);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(icon("🗑", v -> {
            msgs.removeAllViews();
            history = new JSONArray();
        }));
        header.addView(icon("➖", v -> hidePanel()));
        header.addView(icon("✕", v -> stopSelf()));
        header.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy;
            int sx, sy;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    dx = e.getRawX(); dy = e.getRawY(); sx = plp.x; sy = plp.y;
                } else if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                    plp.x = sx + Math.round(e.getRawX() - dx);
                    plp.y = sy + Math.round(e.getRawY() - dy);
                    try { wm.updateViewLayout(panel, plp); } catch (Exception ex) { }
                }
                return true;
            }
        });
        panel.addView(header);

        sv = new ScrollView(themed);
        msgs = new LinearLayout(themed);
        msgs.setOrientation(LinearLayout.VERTICAL);
        msgs.setPadding(dpi(8), dpi(8), dpi(8), dpi(8));
        sv.addView(msgs);
        panel.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout row = new LinearLayout(themed);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dpi(8), dpi(4), dpi(8), dpi(8));
        input = new EditText(themed);
        input.setHint("اكتب سؤالك...");
        input.setHintTextColor(Color.GRAY);
        input.setTextColor(Color.WHITE);
        input.setTextSize(15);
        input.setMaxLines(3);
        input.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        row.addView(input, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button send = new Button(themed);
        send.setText("إرسال");
        send.setOnClickListener(v -> sendMessage());
        row.addView(send);
        panel.addView(row);

        int w = Math.round(sw * 0.92f);
        int h = Math.round(sh * 0.5f);
        plp = new WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        plp.gravity = Gravity.TOP | Gravity.START;
        plp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;
        plp.x = (sw - w) / 2;
        plp.y = Math.round(sh * 0.08f);
    }

    void showPanel() {
        hideBubble();
        if (!panelOn) {
            try { wm.addView(panel, plp); panelOn = true; } catch (Exception e) { }
        }
    }

    void hidePanel() {
        if (panelOn) {
            try { wm.removeView(panel); } catch (Exception e) { }
            panelOn = false;
        }
        showBubble();
    }

    // ---------- chat ----------
    TextView addMsg(String text, boolean user) {
        TextView t = new TextView(themed);
        t.setText(text);
        t.setTextSize(15);
        t.setTextColor(Color.WHITE);
        t.setTextIsSelectable(true);
        t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        t.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
        t.setPadding(dpi(10), dpi(8), dpi(10), dpi(8));
        t.setBackground(rounded(user ? 0xFF2563EB : 0xFF1F2937, 12));
        t.setMaxWidth(Math.round(sw * 0.92f * 0.85f));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dpi(4), 0, dpi(4));
        lp.gravity = user ? Gravity.END : Gravity.START;
        msgs.addView(t, lp);
        sv.post(() -> sv.fullScroll(View.FOCUS_DOWN));
        return t;
    }

    JSONObject msg(String role, String text) {
        try {
            return new JSONObject().put("role", role)
                    .put("parts", new JSONArray().put(new JSONObject().put("text", text)));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    void sendMessage() {
        final String q = input.getText().toString().trim();
        if (q.isEmpty() || busy) return;
        SharedPreferences sp = getSharedPreferences("cfg", 0);
        final String key = sp.getString("key", "");
        final String model = sp.getString("model", "gemini-3.5-flash");
        input.setText("");
        addMsg(q, true);
        if (key.isEmpty()) {
            addMsg("لم يتم إدخال مفتاح Gemini. افتح التطبيق وأدخل المفتاح ثم احفظ.", false);
            return;
        }
        history.put(msg("user", q));
        busy = true;
        final TextView wait = addMsg("جارٍ التفكير...", false);
        final JSONArray snapshot = history;
        new Thread(() -> {
            String result;
            boolean ok = false;
            try {
                JSONObject body = new JSONObject();
                body.put("systemInstruction", new JSONObject().put("parts", new JSONArray().put(new JSONObject()
                        .put("text", "أنت مساعد مفيد. أجب بإيجاز وبنفس لغة المستخدم."))));
                body.put("contents", snapshot);
                HttpURLConnection c = (HttpURLConnection) new URL(
                        "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent").openConnection();
                c.setRequestMethod("POST");
                c.setRequestProperty("x-goog-api-key", key);
                c.setRequestProperty("Content-Type", "application/json");
                c.setConnectTimeout(20000);
                c.setReadTimeout(60000);
                c.setDoOutput(true);
                OutputStream os = c.getOutputStream();
                os.write(body.toString().getBytes("UTF-8"));
                os.close();
                int code = c.getResponseCode();
                InputStream is = code < 400 ? c.getInputStream() : c.getErrorStream();
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while (is != null && (n = is.read(buf)) > 0) bo.write(buf, 0, n);
                String resp = bo.toString("UTF-8");
                if (code >= 400) {
                    String m = resp;
                    try { m = new JSONObject(resp).getJSONObject("error").getString("message"); } catch (Exception ignored) { }
                    result = "خطأ (" + code + "): " + m;
                } else {
                    JSONArray parts = new JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                            .getJSONObject("content").getJSONArray("parts");
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < parts.length(); i++) sb.append(parts.getJSONObject(i).optString("text", ""));
                    result = sb.toString().trim();
                    if (result.isEmpty()) result = "لم يرجع النموذج إجابة.";
                    ok = true;
                }
            } catch (Exception e) {
                result = "تعذر الاتصال: " + e.getMessage();
            }
            final String r = result;
            final boolean good = ok;
            ui.post(() -> {
                wait.setText(r);
                if (good) history.put(msg("model", r));
                else if (history.length() > 0) history.remove(history.length() - 1);
                busy = false;
                sv.post(() -> sv.fullScroll(View.FOCUS_DOWN));
            });
        }).start();
    }
}

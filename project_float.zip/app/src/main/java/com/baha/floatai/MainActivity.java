package com.baha.floatai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    TextView tv(String t, int size, boolean bold) {
        TextView x = new TextView(this);
        x.setText(t);
        x.setTextSize(size);
        x.setTextColor(Color.WHITE);
        x.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        x.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
        if (bold) x.setTypeface(null, android.graphics.Typeface.BOLD);
        x.setPadding(0, dp(8), 0, dp(4));
        return x;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final SharedPreferences sp = getSharedPreferences("cfg", 0);
        getWindow().setStatusBarColor(Color.parseColor("#0f172a"));
        getWindow().setNavigationBarColor(Color.parseColor("#0f172a"));
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#0f172a"));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));
        sv.addView(root);

        root.addView(tv("الذكاء الاصطناعي العائم", 22, true));
        root.addView(tv("مفتاح Gemini API", 15, true));
        final EditText key = new EditText(this);
        key.setHint("AIzaSy...");
        key.setTextColor(Color.WHITE);
        key.setHintTextColor(Color.GRAY);
        key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        key.setText(sp.getString("key", ""));
        root.addView(key);

        Button get = new Button(this);
        get.setText("احصل على مفتاح مجاني");
        get.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey"))));
        root.addView(get);

        root.addView(tv("النموذج", 15, true));
        final EditText model = new EditText(this);
        model.setTextColor(Color.WHITE);
        model.setText(sp.getString("model", "gemini-3.5-flash"));
        root.addView(model);

        Button save = new Button(this);
        save.setText("حفظ");
        save.setOnClickListener(v -> {
            String m = model.getText().toString().trim();
            sp.edit().putString("key", key.getText().toString().trim())
                    .putString("model", m.isEmpty() ? "gemini-3.5-flash" : m).apply();
            Toast.makeText(this, "تم الحفظ", Toast.LENGTH_SHORT).show();
        });
        root.addView(save);

        root.addView(tv("التشغيل", 15, true));
        Button start = new Button(this);
        start.setText("تشغيل النافذة العائمة");
        start.setOnClickListener(v -> {
            sp.edit().putString("key", key.getText().toString().trim()).apply();
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
                Toast.makeText(this, "فعّل \"العرض فوق التطبيقات الأخرى\" ثم ارجع واضغط تشغيل", Toast.LENGTH_LONG).show();
                return;
            }
            startForegroundService(new Intent(this, FloatService.class));
            Toast.makeText(this, "ظهرت الدائرة العائمة، اضغط عليها لفتح الدردشة", Toast.LENGTH_LONG).show();
        });
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("إيقاف النافذة العائمة");
        stop.setOnClickListener(v -> stopService(new Intent(this, FloatService.class)));
        root.addView(stop);

        root.addView(tv("اضغط على الدائرة لفتح الدردشة، واسحبها لتحريكها. داخل الدردشة: ➖ للتصغير إلى دائرة، 🗑 لمسح المحادثة، ✕ للإغلاق. يمكنك سحب شريط العنوان لنقل النافذة.", 13, false));
        setContentView(sv);
    }
}
